const actionRegister = require('../../functions/register/actionRegisterModal');
const { addToQueue } = require('../../queue/actionQueue');

module.exports = async (interaction, client) => {
    if (interaction.customId === 'addaction') {
        await actionRegister(interaction, client);
        return;
    }

    if (interaction.customId === 'entry_action') {
    await interaction.deferReply({ ephemeral: true });
    addToQueue(interaction, client, 'add');
}

if (interaction.customId === 'exit_action') {
    await interaction.deferReply({ ephemeral: true });
    addToQueue(interaction, client, 'remove');
}
};
