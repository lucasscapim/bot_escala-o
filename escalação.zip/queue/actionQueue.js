const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();
const { EmbedBuilder } = require('discord.js');

const delay = (ms = 2000) => new Promise(resolve => setTimeout(resolve, ms));
const queues = new Map();

function addToQueue(interaction, client, type = 'add') {
    const messageId = interaction.message.id;

    if (!queues.has(messageId)) {
        queues.set(messageId, {
            queue: [],
            processing: false,
        });
    }

    const actionQueue = queues.get(messageId);
    actionQueue.queue.push({ interaction, client, type });

    processQueue(messageId);
}

async function processQueue(messageId) {
    const actionQueue = queues.get(messageId);
    if (!actionQueue || actionQueue.processing) return;
    if (actionQueue.queue.length === 0) return;

    actionQueue.processing = true;
    const { interaction, client, type } = actionQueue.queue.shift();

    let logMsg = '';

    const updateReply = async (line) => {
        logMsg += `${line}\n`;
        await interaction.editReply({ content: logMsg });
    };

    try {
        const message = interaction.message;
        const embedAntiga = message.embeds[0];

        await interaction.editReply('⏳ Você entrou na fila, logo será adicionado na ação...');
        logMsg = '⏳ Você entrou na fila, logo será adicionado na ação...';
        await delay();

        await updateReply('\n🔍 Verificando seus dados no banco...');
        const result = await prisma.log.findFirst({ where: { mensagemId: message.id } });

        if (!result) {
            await updateReply('❌ Ação não encontrada no banco de dados.');
            actionQueue.processing = false;
            processQueue(messageId);
            return;
        }

        const resultAction = await prisma.acao.findUnique({ where: { id: result.acaoId } });

        if (!resultAction) {
            await updateReply('❌ Dados da ação não encontrados.');
            actionQueue.processing = false;
            processQueue(messageId);
            return;
        }

        if (type === 'add') {
            if (result.membros.includes(interaction.user.id)) {
                await updateReply('⚠️ Você já está participando desta ação.');
                actionQueue.processing = false;
                processQueue(messageId);
                return;
            }

            await delay();
            await updateReply('🗃 Atualizando banco de dados...');

            const updatedMembers = [...result.membros, interaction.user.id];
            await prisma.log.updateMany({
                where: { mensagemId: message.id },
                data: { membros: updatedMembers }
            });

            await delay();
            await updateReply('📝 Atualizando mensagem com os participantes...');

            const membrosList = updatedMembers.map((id, i) => `${i + 1}. <@${id}>`).join('\n');
            const embedAtualizada = EmbedBuilder.from(embedAntiga).setDescription(
                `Ação selecionada: ${resultAction.nome}\n` +
                `Armamento: ${resultAction.armamento}\n` +
                `Categoria: ${resultAction.categoria}\n\n` +
                `Requisitos:\n\n` +
                `Minimo: ${resultAction.minParticip}\n` +
                `Máximo: ${resultAction.maxParticip}\n\n` +
                `Participantes: \n${membrosList}`
            );

            await message.edit({ embeds: [embedAtualizada] });

            await delay();
            await updateReply(`✅ Você foi adicionado com sucesso na ação **${resultAction.nome}**.`);

        } else if (type === 'remove') {
            if (!result.membros.includes(interaction.user.id)) {
                await updateReply('⚠️ Você não está participando desta ação.');
                actionQueue.processing = false;
                processQueue(messageId);
                return;
            }

            await delay();
            await updateReply('🗃 Atualizando banco de dados...');

            const updatedMembers = result.membros.filter(id => id !== interaction.user.id);
            await prisma.log.updateMany({
                where: { mensagemId: message.id },
                data: { membros: updatedMembers }
            });

            await delay();
            await updateReply('📝 Atualizando mensagem com os participantes...');

            const membrosList = updatedMembers.map((id, i) => `${i + 1}. <@${id}>`).join('\n');
            const embedAtualizada = EmbedBuilder.from(embedAntiga).setDescription(
                `Ação selecionada: ${resultAction.nome}\n` +
                `Armamento: ${resultAction.armamento}\n` +
                `Categoria: ${resultAction.categoria}\n\n` +
                `Requisitos:\n\n` +
                `Minimo: ${resultAction.minParticip}\n` +
                `Máximo: ${resultAction.maxParticip}\n\n` +
                `Participantes: \n${membrosList}`
            );

            await message.edit({ embeds: [embedAtualizada] });

            await delay();
            await updateReply(`✅ Você foi removido com sucesso da ação **${resultAction.nome}**.`);
        }

    } catch (error) {
        console.error('[ERROR] Erro ao processar interação na fila:', error);
        try {
            if (!interaction.replied && !interaction.deferred) {
                await interaction.reply({ content: 'Erro interno, tente novamente.', ephemeral: true });
            } else {
                await updateReply('❌ Erro interno, tente novamente.');
            }
        } catch (_) { }
    } finally {
        actionQueue.processing = false;
        processQueue(messageId);
    }
}

module.exports = { addToQueue };
